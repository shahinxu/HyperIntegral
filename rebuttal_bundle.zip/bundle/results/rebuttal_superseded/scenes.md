# Scene coverage: ours vs baselines (5 seeds)

## scene=ecological, n_nodes=60, noise=0.0

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| sindy_derivative_stlsq | 5 | 0.5056 ± 0.0117 | [0.4911, 0.5201] | 0.0642 | 0.0007 | 0.0625 | *** |
| sindy_integral_stlsq | 5 | 0.4848 ± 0.0109 | [0.4713, 0.4983] | 0.0434 | 0.0017 | 0.0625 | ** |
| sindy_integral_lstsq | 5 | 0.4848 ± 0.0109 | [0.4713, 0.4983] | 0.0434 | 0.0017 | 0.0625 | ** |
| ours **(ref)** | 5 | 0.4414 ± 0.0086 | [0.4307, 0.4521] | — | — | — | — |

## scene=ecological, n_nodes=60, noise=0.05

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| sindy_integral_lstsq | 5 | 0.5351 ± 0.0134 | [0.5185, 0.5518] | 0.0702 | 0.0000 | 0.0625 | *** |
| sindy_integral_stlsq | 5 | 0.5351 ± 0.0134 | [0.5185, 0.5517] | 0.0702 | 0.0000 | 0.0625 | *** |
| sindy_derivative_stlsq | 5 | 0.5337 ± 0.0131 | [0.5173, 0.5500] | 0.0688 | 0.0007 | 0.0625 | *** |
| ours **(ref)** | 5 | 0.4649 ± 0.0188 | [0.4416, 0.4882] | — | — | — | — |

## scene=neuronal, n_nodes=60, noise=0.0

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 5 | 0.5326 ± 0.0162 | [0.5126, 0.5527] | — | — | — | — |
| sindy_integral_stlsq | 5 | 0.5024 ± 0.0122 | [0.4872, 0.5176] | -0.0302 | 0.0061 | 0.0625 | ** |
| sindy_integral_lstsq | 5 | 0.5024 ± 0.0122 | [0.4872, 0.5176] | -0.0302 | 0.0061 | 0.0625 | ** |
| sindy_derivative_stlsq | 5 | 0.5012 ± 0.0103 | [0.4884, 0.5139] | -0.0315 | 0.0512 | 0.0625 | n.s. |

## scene=neuronal, n_nodes=60, noise=0.05

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 5 | 0.5375 ± 0.0150 | [0.5189, 0.5561] | — | — | — | — |
| sindy_integral_lstsq | 5 | 0.5039 ± 0.0075 | [0.4946, 0.5133] | -0.0336 | 0.0177 | 0.0625 | * |
| sindy_integral_stlsq | 5 | 0.5039 ± 0.0075 | [0.4946, 0.5133] | -0.0336 | 0.0177 | 0.0625 | * |
| sindy_derivative_stlsq | 5 | 0.4949 ± 0.0119 | [0.4801, 0.5098] | -0.0426 | 0.0100 | 0.0625 | * |

## scene=social, n_nodes=8, noise=0.0

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| sindy_derivative_stlsq | 5 | 0.5192 ± 0.0770 | [0.4235, 0.6148] | 0.0257 | 0.3989 | 0.8125 | n.s. |
| sindy_integral_stlsq | 5 | 0.4956 ± 0.0345 | [0.4527, 0.5385] | 0.0021 | 0.9092 | 1.0000 | n.s. |
| sindy_integral_lstsq | 5 | 0.4956 ± 0.0345 | [0.4527, 0.5385] | 0.0021 | 0.9092 | 1.0000 | n.s. |
| ours **(ref)** | 5 | 0.4935 ± 0.0448 | [0.4378, 0.5492] | — | — | — | — |

## scene=social, n_nodes=8, noise=0.05

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 5 | 0.5852 ± 0.0576 | [0.5138, 0.6567] | — | — | — | — |
| sindy_derivative_stlsq | 5 | 0.5023 ± 0.0070 | [0.4936, 0.5110] | -0.0830 | 0.0417 | 0.1250 | * |
| sindy_integral_stlsq | 5 | 0.4971 ± 0.0088 | [0.4862, 0.5081] | -0.0881 | 0.0167 | 0.0625 | * |
| sindy_integral_lstsq | 5 | 0.4971 ± 0.0088 | [0.4862, 0.5081] | -0.0881 | 0.0167 | 0.0625 | * |
