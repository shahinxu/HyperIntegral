# Integral vs derivative residual: a noise-governed crossover

960 runs (576 + 384), 8 seeds, Rossler N=8. `control` varies two things that
were suspected of masking the effect: `oracle` builds Phi and f from the
noise-free trajectory (isolating errors-in-variables in the regressor), and
`coarse` skips the dense resampling so the finite-difference step is the raw
grid spacing. Delta = macro-AUC(integral) - macro-AUC(derivative); positive
means the integral residual wins. `*` marks a paired t-test with p < 0.05 over
the 8 seeds.

## Per-cell

| control | grid T | σ=0.01 | σ=0.05 | σ=0.1 | σ=0.15 | σ=0.2 | σ=0.3 |
|---|---|---|---|---|---|---|---|
| plain | 300 | -0.043* | -0.010 | +0.078 | +0.007 | -0.008 | +0.061* |
| plain | 100 | -0.023 | +0.007 | +0.028 | +0.032 | +0.054 | -0.022 |
| coarse | 300 | -0.054* | +0.007 | +0.121* | +0.051 | +0.086 | +0.022 |
| coarse | 100 | -0.084* | +0.003 | +0.038 | -0.009 | +0.012 | +0.007 |
| oracle | 300 | -0.048* | -0.010 | +0.016 | +0.046 | -0.007 | +0.006 |
| oracle | 100 | -0.018 | +0.033 | +0.025 | +0.057 | +0.022 | -0.008 |
| oracle_coarse | 300 | -0.052* | -0.026 | +0.058 | +0.019 | -0.002 | +0.037 |
| oracle_coarse | 100 | -0.107* | -0.034 | -0.016 | +0.008 | +0.007 | +0.117* |

## Pooled over all 8 (control x grid) cells

| σ | mean Δ | cells with Δ>0 | one-sample t p | pooled paired p | verdict |
|---|---|---|---|---|---|
| 0.01 | -0.0536 | 0/8 | 0.0013 | 0.0000 | derivative clearly better |
| 0.05 | -0.0037 | 4/8 | 0.6398 | 0.7045 | tie (crossover) |
| 0.1 | +0.0436 | 7/8 | 0.0218 | 0.0002 | integral better |
| 0.15 | +0.0263 | 7/8 | 0.0173 | 0.0602 | integral better |
| 0.2 | +0.0205 | 5/8 | 0.1236 | 0.1143 | integral mildly better, n.s. |
| 0.3 | +0.0273 | 6/8 | 0.1254 | 0.0444 | integral mildly better |

## Absolute levels (both losses pooled)

| σ | integral | derivative |
|---|---|---|
| 0.01 | 0.7502 | 0.8007 |
| 0.05 | 0.6936 | 0.7030 |
| 0.1 | 0.6689 | 0.6369 |
| 0.15 | 0.6369 | 0.6106 |
| 0.2 | 0.6090 | 0.5884 |
| 0.3 | 0.5893 | 0.5620 |

## What this means

1. **The crossover is real and well localized.** At σ = 0.01 the derivative
   residual wins in 8 of 8 cells (mean -0.054, p = 0.0013). At σ = 0.05 the two
   are indistinguishable (4/8, p = 0.64). At σ = 0.1 the integral residual wins
   in 7 of 8 cells (mean +0.044, p = 0.022). The sign flip reproduces under
   every control, so it is not an artifact of the resampling pipeline or of
   errors-in-variables in the regressor.

2. **This is a bias-variance crossover.** Integrating averages observation
   noise down (lower variance) at the cost of quadrature bias. Below the
   crossover the bias dominates and the integral form is actively harmful;
   above it the variance reduction pays.

3. **The advantage does not keep growing.** Past σ = 0.1 it plateaus at about
   +0.02 to +0.03 and loses significance, because both estimators are decaying
   toward chance (absolute macro-AUC falls from ~0.78 at σ = 0.01 to ~0.55 at
   σ = 0.3). The integral formulation buys a bounded amount of robustness, not
   an asymptotic advantage.

4. **Errors-in-variables in Phi is a large but separate effect.** The `oracle`
   control lifts *both* estimators substantially at high noise (e.g. at σ = 0.1,
   T = 300: 0.681/0.602 -> 0.719/0.703), and it *shrinks* the integral-vs-
   derivative gap (+0.078 -> +0.016). Part of what the integral form buys is
   averaging noise in Phi, not only in the matched increment.

## Consequence for the paper

The unconditional claim that the integral formulation is superior is not
supported. Two claims are supported and should replace it:

- Constrained (bounded, iteratively optimized) estimation beats one-shot
  sparse regression at every noise level, by 0.10 to 0.28 macro-AUC, all
  significant at 8 seeds. This is the main result and does not depend on the
  integral formulation at all.
- The integral residual specifically buys robustness above a characterized
  noise threshold (σ ≈ 0.05 here), with a measured peak benefit of +0.044 at
  σ = 0.1. Stating the threshold is stronger than asserting the claim
  unconditionally, and it is exactly what Theorems 1-2 should be predicting.
