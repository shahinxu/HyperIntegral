# Baseline audit (answers R?-5 directly, and corrects two of our own claims)

The reviewer asks, of HyperPINN: *"it is unclear whether that formulation
applied additional sparsity-promoting cost terms and if it used the same
sigmoid-based parametrization as in this paper."* Both questions have a
definite code-level answer.

## 1. Do the baselines apply sparsity-promoting cost terms? Yes.

| baseline | sparsity terms | weights |
|---|---|---|
| hyperpinn | L1 **and** L0 on every order | L1: edges 0.03, triangles 0.05, quads 0.04, quints 0.03; L0: edges 0.01, triangles 0.02, quads 0.015, quints 0.01 |
| hyperpinn_base | L1 **and** L0 on every order | same as above |
| hyperpinn_cp | L1 on edges/triangles + factor penalty | 0.03 / 0.05 (outer), 0.01 / 0.01 (inner) |
| hyperpinn_tucker | L1 on edges/triangles + factor penalty | same |
| hyperpinn_tensor_train | L1 on edges/triangles + factor penalty | same |
| hyperpinn_ITC_0 | L1 on edges/triangles + factor penalty | 0.01 / 0.01 |
| hyperpinn_ITC_sup | L1 on edges/triangles + factor penalty | 0.01 / 0.01 |

So every baseline already encourages sparsity explicitly, while the proposed
method does not. That makes our Section 4.7 result (adding L1 to our objective
changes nothing) the right answer to the second half of R?-5: sparsity is not
the operative difference.

## 2. Does HyperPINN use the same sigmoid-based parametrization? Partly.

- `hyperpinn` and `hyperpinn_base`: **yes**, `torch.sigmoid` on the per-order
  edge/triangle/quad weights, plus a Gumbel-sigmoid relaxation
  `sigmoid((logits + gumbel) / temperature)` with temperature annealing.
- `hyperpinn_cp`, `hyperpinn_tucker`, `hyperpinn_tensor_train`,
  `hyperpinn_ITC_*`: **no**, these use `softplus` on low-rank factors, not a
  sigmoid on explicit per-hyperedge logits.

So the comparison against `hyperpinn_base` is parametrization-matched; the
comparison against the low-rank variants is not, and that should be stated.

## 3. Staged lambda scheduling lives in the baselines, not in our method

`HyperPINN_Rossler.py` runs an explicit three-stage weight schedule:

| stage | epochs | physics weight | data weight | sparsity weight |
|---|---|---|---|---|
| 1 Data fitting | 0 - 2500 | 0.1 | 1.0 | 0.0 |
| 2 Physics learning | 2500 - 10000 | 0.01 -> 1.0 (linear) | 1.0 -> 0.2 (linear) | 0.0 |
| 3 Sparsification | 10000 - end | 1.0 | 0.2 | 0 -> 0.01 (linear), + temperature annealing |

**This corrects one of our own ablations.** We implemented
`--lambda_schedule staged` in `models/integral/train.py` as an *order-wise*
schedule (2-edges first, then 3, 4, 5). The schedule the reviewer is most
likely referring to is the one above: a data/physics/sparsity weight ramp.
Our integral objective has no data term and no sparsity term by default, so
that schedule has no direct analogue there. The staged-lambda rows in
Section 4.2 therefore answer a different question than the one asked, and
either the ablation or the claim needs to be restated.

## 4. Bugs found and fixed while making the baselines runnable

These are worth knowing because they mean **no usable baseline numbers existed
in this repository before now**.

| bug | effect | fix |
|---|---|---|
| The inner scripts only *print* AUCs; `run.py` parsed a `auc_scores.txt` that is never written | every baseline `summary.json` had an empty `auc` field | parse the AUCs from captured stdout |
| `--n_epochs` / `--lr` accepted by `hyperpinn` and `hyperpinn_base` launchers but never forwarded to the inner script | the epoch budget and learning rate were silently ignored; tuning was impossible | forward them, and expose `--epochs` / `--lr` on the inner scripts |
| `np.random.seed()` called with no argument | baselines reseeded from entropy, so runs were not reproducible and seeds were meaningless | seed from a new `--seed` argument |
| `models/hyperpinn/run.py` never set `ROSSLER_HYPERGRAPH_PRESET` | with `--n_nodes 8` it still loaded the 100-node hypergraph and crashed with an index error | set the preset from `--n_nodes` |
| results directory keyed only by timestamp | parallel sweep runs collided | optional `HYPERPINN_RUN_TAG` |

## 5. Comparability constraint

`hyperpinn_cp`, `hyperpinn_ITC_0` and `hyperpinn_ITC_sup` raise on
`max_order > 3`. A comparison that includes them must run at **max_order = 3**.
Our headline Rossler numbers were produced at max_order = 5 and are therefore
not directly comparable to them; the baseline tables are run at max_order = 3
for all methods.
