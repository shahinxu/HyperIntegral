# Comparison against sparse-regression baselines (Rossler, N=8, 3 seeds)

## scene=rossler, n_nodes=8, noise=0.0

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 3 | 0.8031 ± 0.0421 | [0.6985, 0.9076] | — | — | — | — |
| sindy_derivative_stlsq | 3 | 0.7238 ± 0.0565 | [0.5836, 0.8641] | -0.0792 | 0.1933 | 0.2500 | n.s. |
| sindy_integral_lstsq | 3 | 0.6095 ± 0.0581 | [0.4653, 0.7538] | -0.1936 | 0.0780 | 0.2500 | n.s. |
| sindy_integral_stlsq | 3 | 0.6095 ± 0.0581 | [0.4653, 0.7538] | -0.1936 | 0.0780 | 0.2500 | n.s. |

## scene=rossler, n_nodes=8, noise=0.01

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 3 | 0.8069 ± 0.0369 | [0.7153, 0.8986] | — | — | — | — |
| sindy_integral_lstsq | 3 | 0.4479 ± 0.0428 | [0.3416, 0.5543] | -0.3590 | 0.0083 | 0.2500 | ** |
| sindy_integral_stlsq | 3 | 0.4460 ± 0.1457 | [0.0841, 0.8078] | -0.3610 | 0.0581 | 0.2500 | n.s. |
| sindy_derivative_stlsq | 3 | 0.4274 ± 0.0418 | [0.3237, 0.5312] | -0.3795 | 0.0042 | 0.2500 | ** |

## scene=rossler, n_nodes=8, noise=0.05

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 3 | 0.7362 ± 0.0404 | [0.6359, 0.8365] | — | — | — | — |
| sindy_integral_stlsq | 3 | 0.4893 ± 0.0803 | [0.2898, 0.6889] | -0.2469 | 0.0438 | 0.2500 | * |
| sindy_derivative_stlsq | 3 | 0.4534 ± 0.0940 | [0.2199, 0.6870] | -0.2828 | 0.0328 | 0.2500 | * |
| sindy_integral_lstsq | 3 | 0.4451 ± 0.0827 | [0.2397, 0.6506] | -0.2911 | 0.0375 | 0.2500 | * |

## scene=rossler, n_nodes=8, noise=0.1

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 3 | 0.6235 ± 0.0988 | [0.3780, 0.8691] | — | — | — | — |
| sindy_derivative_stlsq | 3 | 0.5030 ± 0.1150 | [0.2173, 0.7886] | -0.1206 | 0.4237 | 0.5000 | n.s. |
| sindy_integral_stlsq | 3 | 0.4995 ± 0.0912 | [0.2730, 0.7261] | -0.1240 | 0.3675 | 0.5000 | n.s. |
| sindy_integral_lstsq | 3 | 0.4426 ± 0.0363 | [0.3523, 0.5328] | -0.1810 | 0.1339 | 0.2500 | n.s. |
