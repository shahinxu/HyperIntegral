# sigma x h sensitivity (Rossler, N=8, 3 seeds)

Macro-AUC, mean ± std over 3 seeds. The integration step h is inversely
proportional to `n_samples`: the trajectory is simulated on `n_samples`
points over a fixed horizon, so a larger T means a finer quadrature grid.

| sigma \\ n_samples (finer h →) | 100 | 200 | 300 | 600 |
|---|---|---|---|---|
| **0.0** | 0.8040 ± 0.0436 | 0.8025 ± 0.0412 | 0.8031 ± 0.0421 | 0.8032 ± 0.0435 |
| **0.01** | 0.8024 ± 0.1000 | 0.8254 ± 0.0782 | 0.7707 ± 0.0868 | 0.7767 ± 0.0668 |
| **0.05** | 0.7132 ± 0.0605 | 0.6945 ± 0.0719 | 0.7313 ± 0.0485 | 0.7750 ± 0.0259 |
| **0.1** | 0.6230 ± 0.0909 | 0.5961 ± 0.0578 | 0.7043 ± 0.0574 | 0.7330 ± 0.0674 |

## Marginal trends

| axis | value | macro-AUC (mean ± std over the other axis and seeds) |
|---|---|---|
| sigma | 0.0 | 0.8032 ± 0.0364 |
| sigma | 0.01 | 0.7938 ± 0.0750 |
| sigma | 0.05 | 0.7285 ± 0.0559 |
| sigma | 0.1 | 0.6641 ± 0.0836 |
| n_samples | 100 | 0.7356 ± 0.1021 |
| n_samples | 200 | 0.7296 ± 0.1101 |
| n_samples | 300 | 0.7523 ± 0.0653 |
| n_samples | 600 | 0.7720 ± 0.0529 |