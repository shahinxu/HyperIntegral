# Why large-N results sit at chance: the benchmark's coupling normalization

The neuronal-synchronization dynamics scale each order's coupling constant by
`1/n^(k-1)`: pairwise by `kappa/n`, 3-edges by `K/n^2`, 4-edges by `K4/n^3`,
5-edges by `K5/n^4`. The number of *true* hyperedges does not grow with `n`
fast enough to compensate, so each higher-order term's contribution to the
dynamics collapses as `n` grows.

## Coupling constant by order and system size

| N | pairwise κ/n | 3-edge K/n² | 4-edge K4/n³ | 5-edge K5/n⁴ |
|---|---|---|---|---|
| 8 | 1.875e-01 | 6.250e-02 | 3.906e-03 | 2.441e-04 |
| 16 | 9.375e-02 | 1.562e-02 | 4.883e-04 | 1.526e-05 |
| 32 | 4.688e-02 | 3.906e-03 | 6.104e-05 | 9.537e-07 |
| 60 | 2.500e-02 | 1.111e-03 | 9.259e-06 | 7.716e-08 |

## Measured signal, N = 60

Total `dθ/dt` RMS: **1.662e+00**. Differentiated observation noise at σ = 0.05: **8.292e-02**.

| order | contribution RMS | fraction of total signal | vs. σ=0.05 noise floor | observed AUC |
|---|---|---|---|---|
| 3-edge | 1.660e-03 | 1.0e-03 | 2.0e-02× | 0.505 |
| 4-edge | 1.105e-05 | 6.6e-06 | 1.3e-04× | 0.526 |
| 5-edge | 6.683e-08 | 4.0e-08 | 8.1e-07× | 0.514 |
| 2-edge | (κ/n = 2.5e-2, much larger) | — | — | 0.609 |

## Consequence

At N = 60 the 4-edge and 5-edge interactions contribute 1e-5 and 1e-8 of the
total derivative, which is 1e4 to 1e6 times *below* the observation noise
floor and close to float32 resolution. **They are not identifiable by any
method.** The measured AUCs confirm this exactly: every method, ours and all
baselines, sits at 0.50 for orders 3-5 and only the pairwise term (coupling
2.5e-2) carries recoverable signal (0.609).

This also explains the trend already recorded in `Mcro-AUC.txt`, where every
method's macro-AUC decays with node count (ITC: 0.905 at n=8 down to 0.622 at
n=100). That decay is a property of the benchmark's coupling normalization,
not evidence about any method.

## What to do about it

1. **This is the answer to "AUROC 0.6-0.8 is modest".** The ceiling is set by
   how much of the dynamics the higher-order terms actually drive. Reporting
   per-order signal-to-noise alongside per-order AUC makes the ceiling explicit
   and turns a weakness into a characterization.
2. **Large-N results on these scenes should not be used to claim anything**
   about higher-order recovery, by us or by the baselines.
3. If large-N experiments are wanted, the coupling constants need rescaling so
   each order's contribution stays O(1) as N grows (e.g. normalize by the
   number of incident hyperedges rather than by `n^(k-1)`). That is a change to
   the benchmark, and it must be disclosed as such.
