# Proposed method vs tuned sparse-regression baselines (Rossler N=8, 8 held-out seeds)

## scene=rossler, n_nodes=8, noise=0.0

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 8 | 0.7785 ± 0.0584 | [0.7297, 0.8273] | — | — | — | — |
| sindy_derivative_stlsq | 8 | 0.6804 ± 0.0776 | [0.6155, 0.7453] | -0.0981 | 0.0228 | 0.0156 | * |
| sindy_integral_stlsq | 8 | 0.5296 ± 0.0863 | [0.4575, 0.6018] | -0.2489 | 0.0010 | 0.0078 | *** |
| sindy_integral_lstsq | 8 | 0.5296 ± 0.0863 | [0.4575, 0.6018] | -0.2489 | 0.0010 | 0.0078 | *** |

## scene=rossler, n_nodes=8, noise=0.01

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 8 | 0.7664 ± 0.0576 | [0.7183, 0.8146] | — | — | — | — |
| sindy_integral_stlsq | 8 | 0.5606 ± 0.0936 | [0.4824, 0.6389] | -0.2058 | 0.0015 | 0.0078 | ** |
| sindy_integral_lstsq | 8 | 0.5389 ± 0.0676 | [0.4824, 0.5954] | -0.2275 | 0.0001 | 0.0078 | *** |
| sindy_derivative_stlsq | 8 | 0.5124 ± 0.0700 | [0.4538, 0.5709] | -0.2541 | 0.0002 | 0.0078 | *** |

## scene=rossler, n_nodes=8, noise=0.05

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 8 | 0.7022 ± 0.0608 | [0.6513, 0.7531] | — | — | — | — |
| sindy_derivative_stlsq | 8 | 0.4726 ± 0.0895 | [0.3977, 0.5474] | -0.2296 | 0.0024 | 0.0078 | ** |
| sindy_integral_lstsq | 8 | 0.4613 ± 0.0881 | [0.3876, 0.5349] | -0.2409 | 0.0019 | 0.0078 | ** |
| sindy_integral_stlsq | 8 | 0.4233 ± 0.0473 | [0.3838, 0.4629] | -0.2789 | 0.0000 | 0.0078 | *** |

## scene=rossler, n_nodes=8, noise=0.1

| Variant | n seeds | Macro-AUC (mean ± std) | 95% CI | Δ vs ref | paired t p | Wilcoxon p | sig |
|---|---|---|---|---|---|---|---|
| ours **(ref)** | 8 | 0.6249 ± 0.0573 | [0.5770, 0.6728] | — | — | — | — |
| sindy_integral_stlsq | 8 | 0.5155 ± 0.0810 | [0.4478, 0.5833] | -0.1094 | 0.0131 | 0.0156 | * |
| sindy_derivative_stlsq | 8 | 0.4893 ± 0.0853 | [0.4179, 0.5606] | -0.1356 | 0.0050 | 0.0391 | ** |
| sindy_integral_lstsq | 8 | 0.4872 ± 0.0879 | [0.4137, 0.5607] | -0.1377 | 0.0056 | 0.0156 | ** |
